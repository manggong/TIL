import React, { Component } from "react";

class Home extends Component {
    render() {
        return (
            <div>
                <h2>HOME</h2>
                <p>앞집에 사는 개 이름 빙고라지요~ 비아이엔지오 빙고는 개이름</p>
            </div>
        );
    }
}

export default Home;