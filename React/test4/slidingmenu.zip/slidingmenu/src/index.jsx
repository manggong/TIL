import React from "react";
import ReactDOM from "react-dom";
import "./css/index.css";
import MenuContainer from "./MenuContainer";

ReactDOM.render(<MenuContainer />, document.querySelector("#container"));
